// Copyright (c) Harri Rautila, 2012

// This file is part of github.com/hrautila/cvx package. 
// It is free software, distributed under the terms of GNU Lesser General Public 
// License Version 3, or any later version. See the COPYING tile included in this archive.

package checkpnt

import (
    "fmt"
    "testing"
)

func TestCompile(t *testing.T) {
    fmt.Printf("Compiled OK\n")
}
