// Copyright (c) Harri Rautila, 2012

package cvx

import (
    "testing"
)

func TestEmpty(t *testing.T) {
}

// Local Variables:
// tab-width: 4
// End:
