A little vector lib. Implements common vector operations over float64 values.

For documenation see [go.pkgdoc.org][doc].

[doc]: http://go.pkgdoc.org/github.com/proxypoke/vector
