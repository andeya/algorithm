// Go implementation of BLAS (Basic Linear Algebra Subprograms)
package blas
