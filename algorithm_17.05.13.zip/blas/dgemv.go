package blas

// Performs: y = alpha * A * x + beta * y  or y = alpha * A^T * x + beta * y
/*func Dgemv(order Order, TransA Transpose, N, M, KL, KU int,
	alpha float64, A []float64, lda int, X []float64, incX int,
	beta float64, Y []float64, incY int) {

}*/
