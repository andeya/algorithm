# chinaid

Generate and verify the Chinese identity card number.