
int lmT(double * X, int n, int p,
    double * y,
    double nu,
    int maxIter, double tol, char method,
    double * logLikelihood,
    double * coef,
    double * tau);

