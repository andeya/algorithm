pso-go
======

A library of PSO (Particle Swarm Optimization) for golang.

How to install
---------------

Execute a following command.

    go get github.com/tenntenn/pso-go

How to use
---------------

A test program pso_testing.go shows an example of basic usage.
